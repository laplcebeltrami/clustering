function print_pdf(filename)

%figure_bg('w'); 
filename=strcat(filename, '.pdf');
print('-dpdf','-r300', filename);
